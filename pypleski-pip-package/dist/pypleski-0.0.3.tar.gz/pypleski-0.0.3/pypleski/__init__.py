__version__ = "0.0.2"
__author__ = 'Uli Toll'
__credits__ = 'Thanks to the Plesk Team @  Parallels IP Holdings'

